/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'font', 'fr-ca', {
	fontSize: {
		label: 'Taille',
		voiceLabel: 'Taille',
		panelTitle: 'Taille'
	},
	label: 'Police',
	panelTitle: 'Police',
	voiceLabel: 'Police'
} );
